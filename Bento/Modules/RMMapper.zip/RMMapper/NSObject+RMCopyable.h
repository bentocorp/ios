//
//  NSObject+TDCopy.h
//  Roomorama
//
//  Created by Roomorama on 27/12/12.
//  Copyright (c) 2012 Roomorama. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (RMCopyable) <NSCopying>

@end
